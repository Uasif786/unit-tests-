/**
 * Author: Umar Asif
 * Date: April 2025
 * Purpose: Unit tests for Appointment class
 */

package com.contactservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("DC100", futureDate, "Justice League meeting");
        assertEquals("DC100", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Justice League meeting", appt.getDescription());
    }

    @Test
    public void testNullAppointmentId() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Null ID Test");
        });
    }

    @Test
    public void testLongAppointmentId() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("LONGER_THAN_10", futureDate, "Invalid ID");
        });
    }

    @Test
    public void testNullDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("DC101", null, "Null date test");
        });
    }

    @Test
    public void testPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1); // Yesterday
        Date pastDate = cal.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("DC102", pastDate, "Back to the past");
        });
    }

    @Test
    public void testNullDescription() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("DC103", futureDate, null);
        });
    }

    @Test
    public void testLongDescription() {
        Date futureDate = getFutureDate();
        String longDesc = "This is a very long description that definitely exceeds fifty characters in length.";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("DC104", futureDate, longDesc);
        });
    }

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1); // Tomorrow
        return cal.getTime();
    }
}

