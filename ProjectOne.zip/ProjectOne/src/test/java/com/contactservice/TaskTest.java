/**
 * Author: Umar Asif
 * Date: April 2025
 * Purpose: Unit tests for Appointment class
 */

package com.contactservice;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testTaskCreationSuccess() {
        Task spideyTask = new Task("SPIDEY03", "Web Fluid Refill", "Peter refills web cartridges.");
        assertEquals("SPIDEY03", spideyTask.getTaskId());
        assertEquals("Web Fluid Refill", spideyTask.getName());
        assertEquals("Peter refills web cartridges.", spideyTask.getDescription());
    }

    @Test
    void testInvalidTaskID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Speed Test", "Barry Allen breaks speed records.");
        });
    }

    @Test
    void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("FLASH04", null, "Barry Allen breaks speed records.");
        });
    }

    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("LOKI05", "Mischief Planning", null);
        });
    }

    @Test
    void testSettersWorkCorrectly() {
        Task batmanTask = new Task("BATMAN02", "Patrol Gotham", "Stop Joker's latest scheme.");
        batmanTask.setName("Gotham Security Check");
        batmanTask.setDescription("Ensure Gotham is crime-free for the night.");
        assertEquals("Gotham Security Check", batmanTask.getName());
        assertEquals("Ensure Gotham is crime-free for the night.", batmanTask.getDescription());
    }
}

