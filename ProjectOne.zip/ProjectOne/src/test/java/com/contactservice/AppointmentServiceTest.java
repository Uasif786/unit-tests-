/**
 * Author: Umar Asif
 * Date: April 2025
 * Purpose: Unit tests for Appointment class
 */

package com.contactservice;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;

class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @BeforeEach
    void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);  // 100000ms in the future
        Appointment appointment = new Appointment("IronMan101", futureDate, "Doctor's visit");
        appointmentService.addAppointment(appointment);

        assertEquals(appointment, appointmentService.getAppointment("IronMan101"));
    }

    @Test
    void testAddDuplicateAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);  // 100000ms in the future
        Appointment appointment1 = new Appointment("IronMan101", futureDate, "Doctor's visit");
        appointmentService.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            Appointment appointment2 = new Appointment("IronMan101", futureDate, "Follow-up visit");
            appointmentService.addAppointment(appointment2);
        });
    }

    @Test
    void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000);  // 100000ms in the future
        Appointment appointment = new Appointment("Thor202", futureDate, "Check-up");
        appointmentService.addAppointment(appointment);

        appointmentService.deleteAppointment("Thor202");
        assertNull(appointmentService.getAppointment("Thor202"));
    }

    @Test
    void testDeleteNonExistentAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("WonderW01");
        });
    }
}
