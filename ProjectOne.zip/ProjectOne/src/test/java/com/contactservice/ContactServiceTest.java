/**
 * Author: Umar Asif
 * Date: April 2025
 * Purpose: Unit tests for Appointment class
 */

package com.contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService contactService;
    private Contact ironMan;
    private Contact spiderMan;
    private Contact thor;

    //@BeforeEach
    public void setUp() {
        contactService = new ContactService();
        ironMan = new Contact("IRONMAN01", "Tony", "Stark", "1234567890", "10880 Malibu Point");
        spiderMan = new Contact("SPIDEY002", "Peter", "Parker", "9876543210", "Queens, NY");
        thor = new Contact("THOR00003", "Thor", "Odinson", "5555555555", "Asgard");
    }

    //Test
    public void testAddContact() {
        assertTrue(contactService.addContact(ironMan));
        assertTrue(contactService.addContact(spiderMan));
    }

    //@Test
    public void testAddDuplicateContact() {
        contactService.addContact(ironMan);
        assertFalse(contactService.addContact(ironMan)); // Duplicate contact ID
    }

    //@Test
    public void testDeleteContact() {
        contactService.addContact(ironMan);
        assertTrue(contactService.deleteContact("IRONMAN01"));
    }

    //@Test
    public void testUpdateContact() {
        contactService.addContact(thor);
        assertTrue(contactService.updateContact("THOR00003", "Loki", "Odinson", "4444444444", "Midgard"));
    }

    //@Test
    public void testUpdateNonExistentContact() {
        assertFalse(contactService.updateContact("HULK00004", "Bruce", "Banner", "3333333333", "Sakaar"));
    }
}


