/**
 * Author: Umar Asif
 * Date: April 2025
 * Purpose: Unit tests for Appointment class
 */

package com.contactservice;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
    private TaskService taskService;
    private Task ironManTask;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
        ironManTask = new Task("IRONMAN01", "Upgrade Suit", "Tony upgrades Mark LXXXV.");
        taskService.addTask(ironManTask);
    }

    @Test
    void testAddTaskSuccessfully() {
        Task batmanTask = new Task("BATMAN02", "Patrol Gotham", "Stop Joker's latest scheme.");
        taskService.addTask(batmanTask);
        assertEquals(batmanTask, taskService.getTask("BATMAN02"));
    }

    @Test
    void testDeleteTaskSuccessfully() {
        taskService.deleteTask("IRONMAN01");
        assertNull(taskService.getTask("IRONMAN01"));
    }

    @Test
    void testUpdateTaskSuccessfully() {
        taskService.updateTask("IRONMAN01", "Arc Reactor Fix", "Fix arc reactor before next battle.");
        Task updatedTask = taskService.getTask("IRONMAN01");
        assertEquals("Arc Reactor Fix", updatedTask.getName());
        assertEquals("Fix arc reactor before next battle.", updatedTask.getDescription());
    }
}

