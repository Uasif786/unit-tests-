/**
 * Author: Umar Asif
 * Date: April 2025
 * Purpose: Unit tests for Appointment class
 */

package com.contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContact() {
        Contact contact = new Contact("IRONMAN01", "Tony", "Stark", "1234567890", "10880 Malibu Point");
        assertNotNull(contact);
    }

    @Test
    public void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Steve", "Rogers", "9876543210", "Brooklyn, NY"));
    }

    @Test
    public void testInvalidPhoneNumber() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("SPIDEY002", "Peter", "Parker", "123", "Queens, NY"));
    }
}
